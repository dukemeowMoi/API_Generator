To start the server, you must install Node.js in your computer.

For MacOS User:
1. Open the terminal and browse to the /GenerateCode directory
2. Install the required NodeJs library by following commands:
npm install express
npm install mongodb
npm install mysql

3. Start the NodeJs server by the following commands:
npm start

For Windows OS User:
1. Install the required NodeJs library by running the install.bat
2. Start the NodeJs server by running the start.bat